defmodule Project3BonusTest do
  use ExUnit.Case
  doctest Project3Bonus

  test "greets the world" do
    assert Project3Bonus.hello() == :world
  end
end
